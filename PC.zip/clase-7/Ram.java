public class Ram
{
    public int memoria;
    public Ram(int memoria){
        this.memoria = memoria;
    }
}
