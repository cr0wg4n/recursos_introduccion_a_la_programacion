public class Gpu
{
    public int memoria;
    public Gpu(int memoria){
        this.memoria = memoria;
    }
}
