// Reemplaza sin ningun miedo lo que este internamiente en los métodos

public class Practica{
    // 1) Implementar un método que dado un String devuelva un arreglo de caracteres en mayuscula.
    // Ej:
        //entrada
        // "hola mundo"
        //salida
        // ['H','O','L','A',' ','M','U','N','D','O']
    public char[] convertirString(String palabras){
        char[] res = {};
        return res;
    }
    // 2) implementar un metodo que dado un arreglo de Strings imprima una salida encuadrada
    // Ej: 
        //entrada: 
        // ["Hola","soy","un","mensaje"] 
        //salida:
        // ***********
        // * Hola    *
        // * soy     *
        // * un      *
        // * mensaje *
        // ***********
    // Pista: rellena los espacios vacios en funcion a la palabra más larga
    public void imprimirMensajeEncuadrado(String[] palabras){
    }
    
    // 3) Crea un traductor del lenguage Español a Mongus
    // Ej:
        //entrada: 
        // "hola"
        //salida:
        // "olajuh"
    // Revisa atentamente cada caso, el procedimiento es sencillo
    // a la palabra en turno le concatenas un "ju" y finalmente trasladas la primera letra de la palabra al final
    
    // Ej: "pinguino"  ->  "pinguino" + "ju"  ->  "pinguinoju"  ->  "inguinoju"+"p"  ->  "inguinojup"
    public String traductorMongus(String palabra){
        return "";
    }
}