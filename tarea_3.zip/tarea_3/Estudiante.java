public class Estudiante{
    String nombreCompleto;
    int edad;
    int notaPromedio;
    public Estudiante(String nombreCompleto, int edad, int notaPromedio){
        this.nombreCompleto=nombreCompleto;
        this.edad=edad;
        this.notaPromedio=notaPromedio;
    }
}
